#!/bin/bash

echo "./solver ../../src/ai/poadaptive/distribution_b.txt 1 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 1 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 2 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 2 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 4 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 4 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 8 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 8 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 16 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 16 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 32 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 32 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 64 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 64 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 128 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 128 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 256 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 256 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 512 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 512 1000
echo "./solver ../../src/ai/poadaptive/distribution_b.txt 1024 1000"
./solver ../../src/ai/poadaptive/distribution_b.txt 1024 1000

